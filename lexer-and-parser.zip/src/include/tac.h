#ifndef TAC_H
#define TAC_H
void tac_compile(char *src);
void tac_compile_file(const char *filename);
#endif