#ifndef TAC_AS_FRONTEND_H
#define TAC_AS_FRONTEND_H
#include "AST.h"

char *as_f(AST_T *ast);
#endif