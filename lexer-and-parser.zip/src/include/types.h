#ifndef TAC_TYPES_H
#define TAC_TYPES_H
int typename_to_int(const char *name);
#endif