#ifndef TAC_IO_H
#define TAC_IO_H
#include <stdio.h>
#include <stdlib.h>

char *tac_read_file(const char *filename);
#endif