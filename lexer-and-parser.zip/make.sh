#!/bin/sh
make clean
clear
make